<template>
  <div id="visual">
    <h1>Receptes</h1>
    <h2>Receptes casolanes</h2>
    <div v-if="recetas.length">
      <div v-for="(receta, index) in recetas" :key="index" class="receta-card">
        <h3>{{ receta.titulo }}</h3>
        <ul>
          <li v-for="(ingrediente, idx) in receta.ingredientes" :key="idx">
            {{ ingrediente }}
          </li>
        </ul>
        <p>{{ receta.descripcion }}</p>
      </div>
    </div>
    <div v-else>
      <p>Carregant receptes...</p>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      recetas: [],
    };
  },
  mounted() {
    // Carga el archivo JSON
    fetch('recetas.json')
      .then((response) => response.json())
      .then((data) => {
        this.recetas = data;
      })
      .catch((error) => {
        console.error('Error al cargar las receptes:', error);
      });
  },
};
</script>

<style>
#visual {
  text-align: center;
  margin: 20px;
  color: #655454;
}

.receta-card {
  border: 1px solid #ddd;
  border-radius: 10px;
  padding: 20px;
  margin: 20px auto;
  width: 90%; /* Ajusta el ancho al 90% de la pantalla */
  max-width: 1200px; /* Máximo ancho para pantallas grandes */
  text-align: left;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* Añade un pequeño sombreado */
  background-color: #fff; /* Fondo blanco */
}

.receta-card h3 {
  font-family: 'Comic Sans MS', cursive, sans-serif;
  transform: rotate(5deg) skew(-10deg); /* Rotació més forta i inclinació de les lletres */
  margin-bottom: 10px;
  font-size: 24px; /* Tamaño de fuente más grande */
  font-weight: bold;
  color: #fcf5b9;
}

.receta-card ul {
  padding-left: 40px; /* Margen izquierdo más amplio */
  margin-bottom: 20px;
  list-style: disc; /* Cambia a un estilo de lista con viñetas */
  color: #d6d6d6;
}

.receta-card p {
  font-size: 16px; /* Texto más grande para mejor lectura */
  line-height: 1.6; /* Espaciado entre líneas para mejorar la legibilidad */
  color: #d6d6d6;
}
</style>
