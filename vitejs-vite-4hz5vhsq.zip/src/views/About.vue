<template>
  <div id="about">
    <h1 class="parpadeig">Serveis</h1>
    <h2 class="parpadeig-sutil">Serveis que oferim</h2>
    <h4>
      En la nostra empresa oferim una gamma àmplia i variada de serveis, en
      aquest apartat podràs informar-te de tots!
    </h4>

    <div class="card">
      <h3 class="card-title confusio">Menjar precuinat</h3>
      <img
        src="https://github.com/albitadinamita24/audio/blob/main/menjar.jpg?raw=true"
        alt="Imatge del servei"
        class="card-image"
      />
      <button class="card-button" @click="mesInformacio">Més informació</button>
    </div>

    <div class="card">
      <h3 class="card-title confusio">Tallers de cuina</h3>
      <img
        src="https://raw.githubusercontent.com/albitadinamita24/audio/refs/heads/main/menjar_2.webp?=raw=true"
        alt="Imatge del servei"
        class="card-image"
      />
      <button class="card-button" @click="mesInformacio">Més informació</button>
    </div>

    <div class="card">
      <h3 class="card-title confusio">Servei per a events</h3>
      <img
        src="https://raw.githubusercontent.com/albitadinamita24/audio/refs/heads/main/menjar_3.avif?raw=true"
        alt="Imatge del servei"
        class="card-image"
      />
      <button class="card-button" @click="mesInformacio">Més informació</button>
    </div>
  </div>
</template>

<script>
export default {
  methods: {
    mesInformacio() {
      alert('Aquí podrías enlazar más información sobre el servicio.');
    },
  },
};
</script>

<style scoped>
#about {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  margin: 20px;
}

.card {
  display: flex;
  flex-direction: column;
  align-items: center;
  border: 1px solid #ddd;
  border-radius: 10px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  width: 300px;
  padding: 20px;
  text-align: center;
  margin: 20px;
  transition: transform 0.3s ease-in-out; /* Afegim transició per al desplaçament */
}

.card:hover {
  transform: translateY(
    -10px
  ); /* Efecte de desplaçament quan el ratolí passa per sobre */
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Ombra més marcada */
}

.card-title {
  font-size: 18px;
  margin-bottom: 10px;
  font-weight: bold;
}

.card-image {
  width: 100%;
  height: auto;
  border-radius: 5px;
  margin-bottom: 15px;
}

.card-button {
  background-color: #42b983;
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 16px;
  border-radius: 5px;
  transition: background-color 0.3s ease, transform 0.3s ease;
}

.card-button:hover {
  background-color: #369870; /* Canvi de color en hover */
  transform: scale(1.1); /* Efecte de creixement del botó */
}

/* Afegim l'animació de parpelleig i desenfocament al títol i al subtítol */
.parpadeig {
  font-size: 3em; /* Títol gran amb el tamany personalitzat */
  font-weight: bold;
  animation: parpadeig 1s infinite, desfoqueig 0.8s infinite; /* Animació de parpelleig i desfoqueig */
}

.parpadeig-sutil {
  animation: parpadeig 1s infinite, desfoqueig 0.8s infinite; /* Animació sense afectar el tamany */
}

/* Animació per al parpelleig */
@keyframes parpadeig {
  0% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}

/* Animació per al desfoqueig */
@keyframes desfoqueig {
  0%,
  100% {
    filter: blur(2px); /* Lleuger desfoqueig */
  }
  50% {
    filter: blur(4px); /* Més desfoqueig al mig */
  }
}

/* Afegim l'animació de confusió a les lletres de les cartes*/
.confusio {
  font-size: 18px;
  font-weight: bold;
  display: inline-block;
  animation: confusioAnimacio 1s infinite, rotacioLletres 1s infinite,
    desenfocamentLletres 0.5s infinite;
}

/* Animació per a la "confusió" (carta amb lletres inestables) */
@keyframes confusioAnimacio {
  0%,
  100% {
    transform: rotate(0deg);
    opacity: 1;
  }
  25% {
    transform: rotate(15deg);
    opacity: 0.7;
  }
  50% {
    transform: rotate(-15deg);
    opacity: 0.4;
  }
  75% {
    transform: rotate(10deg);
    opacity: 0.6;
  }
}

/* Rotació constant de les lletres per donar l'efecte de confusió */
@keyframes rotacioLletres {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}

/* Desenfocament de les lletres */
@keyframes desenfocamentLletres {
  0%,
  100% {
    filter: blur(1px);
  }
  50% {
    filter: blur(4px);
  }
}
</style>
