<template>
  <h1>Inici</h1>
  <h2>Presentació</h2>
  <h4>
    Aquesta web que presenta barreres d'accés de forma directa a usuaris sense
    discapacitat perquè en interactuar amb elles, empatitzin amb els problemes
    habituals que tenen els usuaris amb discapacitat en fer servir la
    tecnologia. Per a dur a terme aquesta pràctica, hem creat aquesta web sobre
    una empresa de cuina fictícia, on en cada pàgina es trobarà una barrera.
  </h4>
  <h2>Llista de barreres</h2>

  <table>
    <thead>
      <tr>
        <th>Pàgina i enllaç</th>
        <th>Tipus de Barrera</th>
        <th>Explicació</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <a href="/Home.html" target="_self">Inici</a>
        </td>
        <td>Visual Total</td>
        <td>En aquesta pàgina principal no es troba cap barrera</td>
      </tr>
      <tr>
        <td>
          <a href="/About.html" target="_self">Serveis</a>
        </td>
        <td>Cognitiu</td>
        <td>
          Allà es podràn veure els diferents serveis que ofereix l'empresa. Es
          podràn apreciar barreres cognitives com per exemple: textos que es
          mouen, imatges que no es veuen bé i/o botons que no porten enlloc o
          fallen.
        </td>
      </tr>
      <tr>
        <td>
          <a href="/NotFound.html" target="_self">Especials</a>
        </td>
        <td>Auditiu</td>
        <td>
          En la pàgina hi ha diferents videos de receptes per èpoques espcials,
          tot i això, la pàgina presenta barreres auditives ja que aquests
          videos no tenen so ni subtiítols i tampoc es podràn activar. Ademés,
          hem afegit un soroll molest mentre estàs dins la secció.
        </td>
      </tr>
      <tr>
        <td>
          <a href="/Visual.html" target="_self">Receptes</a>
        </td>
        <td>Baixa visió</td>
        <td>
          En aquest apartat s'ensenyen tres receptes casolanes i típiques, però
          no sé si es podrà llegir bé els texts o es podràn apreciar bé les
          imatges...
        </td>
      </tr>
      <tr>
        <td>
          <a href="/Contacte.html" target="_self">Contacte</a>
        </td>
        <td>Motriu</td>
        <td>
          Per contactar amb nosaltres hi haurà alguna barrera motriu, suposo que
          tindràs alguna dificultat per escriure, el ratolí no et farà cas i el
          botó enviar no servirà per a res.
        </td>
      </tr>
    </tbody>
  </table>

  <h2>Reflexió</h2>
  <h4>
    Aquesta activitat ens ha permès posar-nos en la situació de les persones amb
    discapacitat i reflexionar sobre com les barreres tecnològiques poden
    afectar la seva autonomia i qualitat de vida. Pensem que estàn en una
    generació tant avançada, la societat hauria d’eliminar completament aquestes
    barreres per les persones amb discapacitat i garantitzar que tots puguin
    accedir a la informació i a les eines digitals amb les mateixes condicions.
  </h4>
</template>

<style>
table {
  width: 100%;
  border-collapse: collapse;
  margin: 20px 0;
  font-size: 16px;
  text-align: left;
}
th,
td {
  border: 1px solid #dddddd;
  padding: 8px;
}
th {
  background-color: #f4f4f4;
  font-weight: bold;
}
</style>
