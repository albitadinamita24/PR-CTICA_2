<template>
  <div class="page-container">
    <!-- Afegim l'element audio per a reproduir el so -->
    <audio id="background-sound" loop autoplay>
      <source
        src="https://raw.githubusercontent.com/albitadinamita24/audio/refs/heads/main/El%20sonido%20mas%20irritante%20del%20mundo.mp3"
        type="audio/mpeg"
      />
      El teu navegador no suporta aquest element.
    </audio>

    <div class="content">
      <h1>Especials!</h1>
      <h2>Especial Nadal</h2>
      <div class="video-container">
        <iframe
          width="560"
          height="315"
          src="https://www.youtube.com/embed/Of_ld18gsbA?mute=1&controls=0&disablekb=1"
          title="Especial Nadal"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
        ></iframe>
      </div>
      <h2>Especial Pasqua</h2>
      <div class="video-container">
        <iframe
          width="560"
          height="315"
          src="https://www.youtube.com/embed/IurcNdZeB-E?mute=1&controls=0&disablekb=1"
          title="Especial Pasqua"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
        ></iframe>
      </div>
      <h2>Especial Castanyada</h2>
      <div class="video-container">
        <iframe
          width="560"
          height="315"
          src="https://www.youtube.com/embed/HoPwb8CUXqM?mute=1&controls=0&disablekb=1"
          title="Especial Castanyada"
          frameborder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowfullscreen
        ></iframe>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'SpecialsPage',
  mounted() {
    // Reproduir el so automàticament quan la pàgina es carrega
    const audio = document.getElementById('background-sound');
    audio.play();
  },
};
</script>

<style scoped>
/* Eliminar centrat del contingut */
.page-container {
  display: block; /* No utilitzem flexbox, el contingut ocupa l'espai disponible */
  margin: 0; /* Eliminar marges per defecte */
  padding: 20px; /* Afegir algun espai intern si ho desitges */
}

/* Estils generals per al contingut */
.content {
  text-align: left; /* El text no està centrat, el deixem a l'esquerra */
}

/* Estil per als vídeos */
.video-container {
  margin: 20px 0; /* Espaiat entre vídeos */
}
</style>
