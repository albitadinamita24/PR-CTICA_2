<template>
  <div id="app">
    <h1>Contacta'ns!</h1>
    <form @submit.prevent="enviarFormulario">
      <div>
        <label for="correo">Adreça electrònica:</label>
        <input
          type="email"
          id="correo"
          v-model="formulario.correo"
          placeholder="Escriu el teu correu electrònic"
          required
          @mouseenter="startMouseChaos"
          @mouseleave="stopMouseChaos"
        />
      </div>
      <div>
        <label for="nombre">Nom:</label>
        <input
          type="text"
          id="nombre"
          v-model="formulario.nombre"
          placeholder="Indica'ns com vols que ens dirigim a tu"
          required
          @mouseenter="startMouseChaos"
          @mouseleave="stopMouseChaos"
        />
      </div>
      <div>
        <label for="telefono">Número de telèfon:</label>
        <input
          type="tel"
          id="telefono"
          v-model="formulario.telefono"
          placeholder="Escriu el teu número de telèfon"
          required
          @mouseenter="startMouseChaos"
          @mouseleave="stopMouseChaos"
        />
      </div>
      <div>
        <label for="mensaje">Missatge:</label>
        <textarea
          id="mensaje"
          v-model="formulario.mensaje"
          placeholder="Què ens vols dir?!"
          readonly
          @mouseenter="startMouseChaos"
          @mouseleave="stopMouseChaos"
        ></textarea>
      </div>
      <button type="submit">Enviar</button>
    </form>
  </div>
</template>

<script>
export default {
  data() {
    return {
      formulario: {
        correo: '',
        nombre: '',
        telefono: '',
        mensaje: '',
      },
      intervalId: null, // Emmagatzema l'interval per moure el cursor
    };
  },
  methods: {
    enviarFormulario() {
      console.log('Formulario enviat amb les dades següents:', this.formulario);
      alert('Gràcies per contactar amb nosaltres! Hem rebut el teu missatge.');
      // Reseteja el formulari
      this.formulario = {
        correo: '',
        nombre: '',
        telefono: '',
        mensaje: '',
      };
    },
    startMouseChaos() {
      // Amaga el cursor i comença el moviment erràtic
      document.body.style.cursor = 'none'; // Amaga el cursor
      this.intervalId = setInterval(() => {
        const randomX = Math.random() * window.innerWidth;
        const randomY = Math.random() * window.innerHeight;
        // Mou la finestra de manera més erràtica
        window.scrollTo(randomX, randomY);
      }, 50); // Incrementem la velocitat a 50 ms per fer-ho més ràpid
    },
    stopMouseChaos() {
      // Torna a mostrar el cursor i para el moviment
      document.body.style.cursor = 'default'; // Torna el cursor a la normalitat
      clearInterval(this.intervalId); // Atura el moviment
    },
  },
};
</script>

<style>
#app {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  margin: 20px;
}
form {
  max-width: 400px;
  margin: 0 auto;
}
div {
  margin-bottom: 15px;
}
label {
  display: block;
  font-weight: bold;
  margin-bottom: 5px;
}
input,
textarea {
  width: 100%;
  padding: 8px;
  box-sizing: border-box;
}
button {
  background-color: #42b983;
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
  font-size: 16px;
}
button:hover {
  background-color: #369870;
}

/* Afegim estil per mantenir el cursor amagat en els camps */
input,
textarea {
  cursor: none; /* El cursor es manté ocult quan està dins dels camps */
}
</style>
