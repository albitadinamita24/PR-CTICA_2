<script setup lang="ts">
import { ref, computed } from 'vue';
import Home from './views/Home.vue';
import About from './views/About.vue';
import NotFound from './views/NotFound.vue';
import Visual from './views/Visual.vue';
import Contacte from './views/Contacte.vue';

const routes = {
  '/': Home,
  '/about': About,
  '/visual': Visual,
  '/contacte': Contacte,
};

const currentPath = ref(window.location.hash);

window.addEventListener('hashchange', () => {
  currentPath.value = window.location.hash;
});

const currentView = computed(
  () => routes[currentPath.value.slice(1) || '/'] || NotFound
);
</script>

<template>
  <nav class="menu">
    <a href="#/">Inici</a> | <a href="#/about">Serveis</a> |
    <a href="#/non-existent-path">Especials</a> |
    <a href="#/visual">Receptes</a> |
    <a href="#/contacte">Contacte</a>
  </nav>

  <Component :is="currentView" />
</template>
